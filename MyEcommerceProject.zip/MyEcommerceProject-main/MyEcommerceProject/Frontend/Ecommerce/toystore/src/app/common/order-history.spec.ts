import { OrderHistory } from './order-history';

describe('OrderHistory', () => {
  it('should create an instance', () => {
    expect(new OrderHistory()).toBeTruthy();
  });
});
